/*(c) Copyright 2003-2009��C*Core rights reserved */

//******************************************************************************
#ifndef	__SHA_H__
#define	__SHA_H__


extern void dynamic_get_hash(void);

#endif

