/*
 * CCM_Types.h
 *
 *  Created on: 2016��9��14��
 *      
 */

#ifndef CCM_TYPES_H_
#define CCM_TYPES_H_

typedef          unsigned char   U8;
typedef            signed char   S8;
typedef volatile unsigned char   VU8;
typedef          unsigned short  U16;
typedef            signed short  S16;
typedef volatile unsigned short  VU16;
typedef          unsigned int    U32;
typedef            signed int    S32;
typedef volatile unsigned int    VU32;


#endif /* CCM_TYPES_H_ */
