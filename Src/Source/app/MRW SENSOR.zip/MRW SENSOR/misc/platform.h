#ifndef __PLATFORM_H__
#define __PLATFORM_H__


#include "eflash_api.h"
#include "config.h"


#if 1
/* Flash Space plan :
 * 0. 1K system used
 * 1. 0.5K properties
 * 2. 26K backgroud image
 * 3. 1K badpoint
 * 4. 1K latest match record
 * 5. 1K top finger templates
 * 6. 0.5K for sensor configuation
 */
#define SENSOR_DATA_OFFSET                      (CODE_LENGTH)   // Code in flash = 128K
//#define SESNOR_DATA_SIZE                        (32)            // Data in falsh = 32K


#define SENSOR_PROPERTY_ADDR                    (EFM0_MAIN_BASEADDR + 1024 * (SENSOR_DATA_OFFSET + 1))   // 1K for system used

#define VALID_EFLASH_SPACE(addr, size)          (((addr) > EFM0_MAIN_BASEADDR) && (((addr) + (size)) <= EFM2_MAIN_BASEADDR + (124*1024))) //\
                                                // && (((addr) >= EFM2_MAIN_BASEADDR) || (((addr) + (size)) <= EFM2_MAIN_BASEADDR - 9 *EFLASH_PAGESIZE)))
#define VALID_SPIFLASH_SPACE(addr, size)        (((addr) < SPI_FLASH_SIZE) && (((addr) +(size)) <= SPI_FLASH_SIZE))

#define SPIFLASH_LOGIC_OFFSET                   (0x80000000)    // logical address offset for SPI flash

#define ROUND_UP(x, aligned)                    (((x) + (aligned) - 1) / (aligned) * (aligned))

typedef struct flash_space_s {
	uint32_t prop_start;
	uint32_t bkg_start;
	uint32_t badpoint_start;
	uint32_t match_rcrd_start;
	uint32_t templates_start;
	uint32_t sensor_cfg_start;
	uint32_t subtpls_start;
} flash_space_t;


extern flash_space_t flash_space;
#else



#define ROUND_UP(x, aligned)                    (((x) + (aligned) - 1) / (aligned) * (aligned))

#define SENSOR_DATA_OFFSET                      (128)		// code & data in flash = 128K 

#define SENSOR_PROPERTY_ADDR                    (EFM0_MAIN_BASEADDR + 1024 * (SENSOR_DATA_OFFSET + 4))   // 4K for system used

#define VALID_EFLASH_SPACE(addr, size)          (((addr) >= EFM0_MAIN_BASEADDR) && ((addr) + (size) <= (EFM0_MAIN_BASEADDR + 1* 508 * 1024)))


/////////////////////////// Templates Flash related configuration start ///////////////////////////////

// 4K for SYSTEM, 4K prop, 16 for bkg, 4K for match record, 8K for finger template related
#define TPLS_EFLASH1_START                      (EFM0_MAIN_BASEADDR + 1024 * (SENSOR_DATA_OFFSET + 36))
#define TPLS_EFLASH1_END                        (EFM0_MAIN_BASEADDR + 1024 * (SENSOR_DATA_OFFSET+ 36 + 128))

#define TPLS_EFLASH2_START                      (TPLS_EFLASH1_END)
#define TPLS_EFLASH2_END                        (TPLS_EFLASH1_END+ 1024 * 216)

#endif



extern int32_t platform_create(void);
extern int32_t platform_destroy(void);
extern int32_t platform_spi_write_read(const void* cpWriteBuf, int nWriteSize, void* pReadBuf, int nReadSize);
extern int32_t platform_msleep(uint32_t ms);
extern int32_t platform_fs_read(uint32_t addr, void *buf, uint32_t size);
extern int32_t platform_fs_write(uint32_t addr, void *buf, uint32_t size, uint32_t key);
extern int32_t platform_fs_page_size(void);
extern int32_t platform_fs_erase_page(uint32_t addr, uint32_t key);
extern int32_t platform_fs_write_dword_tag(uint32_t addr, uint32_t val, uint32_t key);
extern int32_t platform_get_jiffies(uint32_t *jiffies);

#endif

