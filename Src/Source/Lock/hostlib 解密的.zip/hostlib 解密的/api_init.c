/**
 * Copyright (C) 2017  Alibaba Group Holding Limited.
 */

#include "ali_crypto.h"
#include "ls_hal_crypt.h"

ali_crypto_result ali_crypto_init(void)
{
    return ALI_CRYPTO_SUCCESS;
}

void ali_crypto_cleanup(void)
{
    return;
}

