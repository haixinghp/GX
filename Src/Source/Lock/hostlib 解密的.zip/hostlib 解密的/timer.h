
#include <stdint.h>


void delayms(uint32_t cnt);
void delayus(uint32_t cnt);
void init_timeout_ms(uint32_t timeout_ms);
uint8_t check_timeout_ms(void);